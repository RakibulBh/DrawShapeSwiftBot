import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;
import java.io.FileWriter;

import swiftbot.*;

public class DrawShape {

	static int[] lengths;
	static String shape;
	static boolean x_pressed = false;

	public static void main(String[] args) throws InterruptedException {
		SwiftBotAPI sb;

		// BOT speed = 0.028cm/ms
		try {
			sb = new SwiftBotAPI();
		} catch (Exception e) {
			System.out.println("Error: could not start SwiftBot");
			return;
		}

		try {
			File stats = new File("swiftbot_stats.txt");
			if (stats.createNewFile()) {
				System.out.println("SwiftBot: stats database created.");
			} else {
				System.out.println("SwiftBot: stats file found. ");
			}
		} catch (IOException e) {
			System.out.println("SwiftBot: error has occurred while creating or finding file. Please try again.");
			x_pressed = true;
		}

		System.out.println("SwiftBot: Welcome to Draw the Shape!");
		System.out.println("SwiftBot: Please have a QR code ready with text in this format: S 25 or for a triangle T 20 20 20, you can change the lengths as you like but between 15 to 85cm. Thank you.");

		sb.enableButton(Button.X, () -> stopProgram(sb));

		boolean QR_CODE_VALID;

		Scanner scanner = new Scanner(System.in);
		Scanner end = new Scanner(System.in);
		while (!x_pressed) {
			System.out.print("SwiftBot: to exit the program and head to the stats press X on the robot and then type 'X' here. Othwerwise type anything else: ");
			String exit = end.next().toUpperCase();
			if ((exit.charAt(0) == 'X') && (x_pressed)) {
				break;
			} 
			QR_CODE_VALID = false;
			lengths = new int[3];
			while (!QR_CODE_VALID) {
				System.out.print("SwiftBot: When you are ready to scan the QR code please type 1: ");
				light(sb, "none");
				String codeEntered = scanner.next();
				if (codeEntered.equals("1")) {
					System.out.println("SwiftBot: Taking a picture in 3 seconds!");
					Thread.sleep(3000);
					String decodedMessage;
					try {
						BufferedImage qrCode = sb.getQRImage();
						decodedMessage = sb.decodeQRImage(qrCode);
					} catch (Exception e) {
						decodedMessage = "";
					}
					if (decodedMessage.isEmpty()) {
						light(sb, "error");
						System.out.println("Error: message was not detected. Please try again.");
					} else {
						if (validate_shape(sb, decodedMessage.toUpperCase())) {
							if (shape.charAt(0) == 'S') {
								System.out.print(String.format("SwiftBot: detected shape: square with length of %d. Is this correct? [Y/N]: ", lengths[0]));
							} else if (shape.charAt(0) == 'T') {
								System.out.print(String.format("SwiftBot: detected shape: triangle with length of %d, %d, %d. Is this correct? [Y/N]: ", lengths[0], lengths[1], lengths[2]));
							}
							String userInput = scanner.next();
							if (userInput.equalsIgnoreCase("Y")) {
								QR_CODE_VALID = true;
							}
						} else {
							light(sb, "error");
							Thread.sleep(3000);
						}
					}
				} else {
					light(sb, "error");
					System.out.println("Error: invalid input. Please try again!");
				}
			}

			if (!x_pressed) {
				switch (shape) {
				case "S":
					drawSquare(sb);
					break;
				case "T":
					drawTriangle(sb);
					break;
				default:
					System.out.println("Error: invalid shape!");
					break;
				}
			}
		}
		
		light(sb, "none");
		scanner.close();
		System.out.println("SwiftBot: please wait as I am loading the statistics...");
		displayData();
		System.out.println("SwiftBot: program has ended!");
	}

	private static void stopProgram(SwiftBotAPI sb) {
		x_pressed = true;
		sb.disableButton(Button.X);
	};

	public static void light(SwiftBotAPI sb, String status) {
		int[] RED = {255, 0, 0};
		int[] GREEN = {0, 0, 255};
		int[] BLUE = {0, 255, 0};

		Underlight[] BUTTONS = {Underlight.FRONT_RIGHT, Underlight.FRONT_LEFT, Underlight.MIDDLE_RIGHT, Underlight.MIDDLE_LEFT, Underlight.BACK_RIGHT, Underlight.BACK_RIGHT, Underlight.BACK_LEFT};

		switch(status) {
		case "error":
			for (int i = 0; i<BUTTONS.length; i++) {
				sb.setUnderlight(BUTTONS[i], RED);
			}
			return;
		case "valid":
			for (int i = 0; i<BUTTONS.length; i++) {
				sb.setUnderlight(BUTTONS[i], GREEN);
			}
			return;
		case "drawing":
			for (int i = 0; i<BUTTONS.length; i++) {
				sb.setUnderlight(BUTTONS[i], BLUE);
			}
			return;
		default:
			for (int i = 0; i<BUTTONS.length; i++) {
				sb.disableUnderlights();
			}
		}
	}


	public static boolean isTPossible() {
		if (lengths.length == 3) {
			return ((lengths[0] + lengths[1] > lengths[2]) && 
					(lengths[0] + lengths[2] > lengths[1]) && 
					(lengths[1] + lengths[2] > lengths[0])); 
		} else {
			return false; 
		}
	}

	// just a function to calculate the angles and then convert to degrees from radians
	public static double calculateAngles(double a, double b, double c) {
		System.out.println("SwiftBot: calculating angles...");
		double angleInRadians = Math.acos((a * a + b * b - c * c) / (2 * a * b));
		return Math.toDegrees(angleInRadians);
	};


	public static float calculateTimeInMillis(int i) {
		double SPEED = 0.028f; //speed in cm/ms because time is in ms
		if (lengths[i] != 0) {
			return (float) (lengths[i] / SPEED); 
		} else {
			return 1;
		}
	}


	public static boolean drawTriangle(SwiftBotAPI sb) {
		if (!isTPossible()) {
			System.out.println("Error: Triangle not possible");
			light(sb, "error");
			return false;
		}

		// calculating each angle for the triangle
		double[] angles = new double[3];
		angles[0] = calculateAngles(lengths[0], lengths[1], lengths[2]);
		angles[1] = calculateAngles(lengths[2], lengths[0], lengths[1]);
		angles[2] = calculateAngles(lengths[1], lengths[2], lengths[0]);


		// calculating the time for each angle to be rotated
		int[] angleMovements = new int[3];
		angleMovements[0] = (int) (3.5 * angles[0]);
		angleMovements[1] = (int) (3.5 * angles[1]);
		angleMovements[2] = (int) (3.5 * angles[2]);

		light(sb, "drawing");
		long startTime = System.nanoTime();
		for (int i = 0; i < 3; i++) {
			int time = (int) calculateTimeInMillis(i);
			sb.move(100, 100, time);
			sb.move(100, -100, angleMovements[i]);
			sb.stopMove();
		}
		light(sb, "valid");
		long endTime = System.nanoTime();
		double time = timeTaken(endTime - startTime);
		String sizes = String.join(",", Arrays.stream(lengths).mapToObj(String::valueOf).toArray(String[]::new));
		storeData("T " + sizes + " " + time);

		return true;
	}

	public static void drawSquare(SwiftBotAPI sb) {
		int time = (int) Math.ceil(calculateTimeInMillis(0));

		light(sb, "drawing");
		long startTime = System.nanoTime();
		for (int i = 0; i < 4; i++) {
			sb.move(100, 100, time);
			sb.stopMove();
			sb.move(100, -100, 315);
		}
		light(sb, "valid");
		long endTime = System.nanoTime();
		double timeTook = timeTaken(endTime - startTime);
		storeData("S " + lengths[0] + " " + timeTook);
	}

	public static double timeTaken(long nanos) {
		double secs = (double) nanos / TimeUnit.NANOSECONDS.convert(1, TimeUnit.SECONDS);
		double rounded = (double) Math.round(secs * 100) / 100;
		System.out.println(String.format("SwiftBot: that took %.2f seconds!", rounded));
		return rounded;
	}

	public static boolean validate_shape(SwiftBotAPI sb, String decodedMessage) {
		String[] shapeInfo = decodedMessage.split(" ");

		switch (shapeInfo[0]) {
		case "S":
			if (shapeInfo.length != 2) {
				System.out.println("Error: insufficient information for square.");
				light(sb, "error");
				return false;
			}
			try {
				int length = Integer.parseInt(shapeInfo[1]);
				if (length >= 15 && length <= 85) {
					lengths[0] = length;
					shape = "S";
					return true;
				} else {
					System.out.println("Error: square length should be between 15cm and 85cm.");
					light(sb, "error");
					return false;
				}
			} catch (NumberFormatException e) {
				System.out.println("Error: square length is invalid.");
				light(sb, "error");
				return false;
			}
		case "T":
			if (shapeInfo.length != 4) {
				System.out.println("Error: insufficient information for triangle.");
				light(sb, "error");
				return false;
			}
			try {
				for (int i = 1; i <= 3; i++) {
					int length = Integer.parseInt(shapeInfo[i]);
					if (length < 15 || length > 85) {
						System.out.println("Error: length" + i + " is invalid.");
						light(sb, "error");
						return false;
					}
					lengths[i - 1] = length;
				}
				shape = "T";
				return true;
			} catch (NumberFormatException e) {
				System.out.println("Error: triangle lengths are invalid.");
				light(sb, "error");
				return false;
			}
		default:
			System.out.println("Error: invalid shape! Please try again.");
			light(sb, "error");
			return false;
		}
	}

	// data handlers


	public static boolean displayData() throws InterruptedException {
	    String fastest = "";
	    double fastestTime = Double.MAX_VALUE;
	    int squareCount = 0;
	    int triCount = 0;
	    double averageTime = 0;
	    String largestShape = "";
	    int largestLength = 0;

	    String[] lastThreeShapes = new String[3];
	    int index = 0;

	    try (Scanner reader = new Scanner(new File("swiftbot_stats.txt"))) {
	        while (reader.hasNextLine()) {
	            String data = reader.nextLine();
	            String[] shapeInfo = data.split(" ");
	            char shapeType = shapeInfo[0].charAt(0);

	            if (shapeType == 'S') {
	                squareCount++;
	                if ((Integer.parseInt(shapeInfo[1]) > largestLength)) {
	                    largestShape = data;
	                    largestLength = (Integer.parseInt(shapeInfo[1]));
	                }
	            } else {
	                triCount++;
	                int sum = 0;
	                String[] triLengths = shapeInfo[1].split(",", 3);
	                for (String length : triLengths) {
	                    sum += Integer.parseInt(length);
	                }
	                if (sum/3 > largestLength) {
	                    largestLength = sum;
	                    largestShape = data;
	                }
	            }

	            double time = Double.parseDouble(shapeInfo[2]);
	            averageTime += time;

	            if (time < fastestTime) {
	                fastestTime = time;
	                fastest = data;
	            }

	            if (index < 3) {
	                lastThreeShapes[index] = data;
	            } else {
	                lastThreeShapes[0] = lastThreeShapes[1];
	                lastThreeShapes[1] = lastThreeShapes[2];
	                lastThreeShapes[2] = data;
	            }
	            index++;
	        }

	        System.out.println(String.format("Data: fastest shape drawn: %ss", fastest));
	        Thread.sleep(500);
	        System.out.println(String.format("Data: average time taken for each shape: %.2fs", averageTime / (squareCount + triCount)));
	        Thread.sleep(500);
	        if (squareCount > triCount) {
	            System.out.println(String.format("Data: most common shape: square, drawn %d times.", squareCount));
	        } else {
	            System.out.println(String.format("Data: most common shape: triangle, drawn %d times.", triCount));
	        }
	        Thread.sleep(500);
	        System.out.println(String.format("Data: largest shape drawn: %ss", largestShape));

	        System.out.println("SwiftBot: last three shapes drawn:");
	        for (String shape : lastThreeShapes) {
	            if (shape != null) {
	                System.out.println(shape);
	            }
	        }

	        return true;
	    } catch (IOException e) {
	        System.out.println("Error: an error occurred while trying to display the data.");
	        return false;
	    }
	}


	public static void storeData(String data) {
		try {
			FileWriter store = new FileWriter("swiftbot_stats.txt", true);
			store.write(data + "\n"); 
			store.close();
			System.out.println("SwiftBot: successfully saved data to file.");
		} catch (IOException e) {
			System.out.println("Error: an error has occurred while saving data to the file.");
		}
	}

}
